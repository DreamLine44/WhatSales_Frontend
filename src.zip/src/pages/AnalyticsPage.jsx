import { useEffect, useState, useCallback } from 'react';
import { BarChart3, TrendingUp, ShoppingCart, Calendar, RefreshCw } from 'lucide-react';
import { dashApi } from '../api.js';
import { PageHeader, StatCard, Card, Btn, Spinner, InlineSelect } from '../components/ui.jsx';
import toast from 'react-hot-toast';

function MetricBar({ label, value, displayValue, color, max, suffix = '' }) {
  const [animated, setAnimated] = useState(false);
  useEffect(() => { const t = setTimeout(() => setAnimated(true), 80); return () => clearTimeout(t); }, []);
  const pct = max > 0 ? Math.min((value / max) * 100, 100) : 0;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontSize: '0.845rem', color: 'var(--text-secondary)', fontWeight: 500 }}>{label}</span>
        <span style={{ fontSize: '0.975rem', fontWeight: 800, color, fontFamily: 'var(--font-display)', letterSpacing: '-0.02em' }}>
          {displayValue ?? value}{suffix}
        </span>
      </div>
      <div style={{ height: 7, borderRadius: 99, background: 'var(--bg-overlay)', overflow: 'hidden' }}>
        <div style={{
          height: '100%', borderRadius: 99, background: color,
          width: animated ? `${pct}%` : '0%',
          transition: 'width 0.7s cubic-bezier(0.34,1.56,0.64,1)',
        }} />
      </div>
    </div>
  );
}

export default function AnalyticsPage() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [days, setDays] = useState(30);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    dashApi.analytics(days)
      .then(r => setData(r.data))
      .catch(err => { setError(err.message); toast.error(err.message); })
      .finally(() => setLoading(false));
  }, [days]);

  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => { load(); }, [load]);

  const maxActivity = data ? Math.max(data.orders ?? 0, data.bookings ?? 0, 1) : 1;

  return (
    <div className="fade-in">
      <PageHeader
        icon={BarChart3} title="Analytics" subtitle="Business performance overview"
        actions={
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <InlineSelect value={days} onChange={v => setDays(Number(v))}>
              <option value={7}>Last 7 days</option>
              <option value={30}>Last 30 days</option>
              <option value={90}>Last 90 days</option>
            </InlineSelect>
            <Btn variant="ghost" size="sm" onClick={load}><RefreshCw size={14} /></Btn>
          </div>
        }
      />

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}><Spinner size={28} /></div>
      ) : error ? (
        <Card><p style={{ textAlign: 'center', color: 'var(--red)', padding: '40px 0' }}>{error} <Btn size="sm" variant="ghost" onClick={load} style={{ marginLeft: 10 }}>Retry</Btn></p></Card>
      ) : !data ? (
        <Card><p style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '40px 0' }}>No analytics data available yet.</p></Card>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }} className="stagger">
          {/* Stat cards */}
          <div className="grid-auto">
            <StatCard label="Total Orders"   value={data.orders   ?? '—'} icon={ShoppingCart} color="green" sub={`Last ${days} days`} />
            <StatCard label="Total Bookings" value={data.bookings ?? '—'} icon={Calendar}     color="blue"  sub={`Last ${days} days`} />
            <StatCard
              label="Revenue"
              value={data.revenue != null ? `D ${Number(data.revenue).toFixed(0)}` : '—'}
              icon={TrendingUp} color="amber" sub="Confirmed orders"
            />
          </div>

          {/* Activity metrics */}
          <Card>
            <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.95rem', marginBottom: 20, letterSpacing: '-0.02em' }}>
              Activity — Last {data.days || days} days
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
              <MetricBar label="Orders placed"  value={data.orders   ?? 0} color="var(--primary)" max={maxActivity} />
              <MetricBar label="Bookings made"  value={data.bookings ?? 0} color="var(--blue)"    max={maxActivity} />
              <MetricBar
                label="Revenue earned"
                value={data.revenue || 0}
                displayValue={`D ${Number(data.revenue || 0).toFixed(0)}`}
                color="var(--amber)" max={Math.max(data.revenue || 0, 1)}
              />
            </div>
          </Card>

        </div>
      )}
    </div>
  );
}
