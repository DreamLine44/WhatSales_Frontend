import { useEffect, useState } from 'react';
import { UtensilsCrossed, Plus, Trash2, Pencil, Check, X, ToggleLeft, ToggleRight, Image as ImageIcon, Upload, ChevronDown, ChevronUp } from 'lucide-react';
import { menuApi, bizApi, formatMoney } from '../api.js';
import { useAuth } from '../store/AuthContext.jsx';
import { PageHeader, Card, Btn, EmptyState, Spinner, Input, Toggle } from '../components/ui.jsx';
import toast from 'react-hot-toast';

// Menu uses the dedicated /dashboard/:tenantId/menu CRUD endpoints.
// GET    /menu              → { menuItems, count }
// POST   /menu              → 201 { menuItems }
// PATCH  /menu/:itemId      → { menuItems }   ← edit by _id, NOT by name
// DELETE /menu/:itemId      → { ok: true }    ← delete by _id, NOT by name
// ⚠ price must be a Number, not a string
// ⚠ always use _id for update/delete — never item name
//
// [MENU-FIELDS-1] BusinessConfig's menuItemSchema supports several fields this
// page never exposed: stockCount (per-item inventory — auto-decrements on
// order, flips available:false at 0), category (drives the salon flow's
// services-vs-products split), currency (per-item override), duration/prep
// (salon-style appointment items), tags, variants (sizes/options), and
// showImageOnSelect. All are optional — tucked behind an "Advanced options"
// disclosure so the common case (name/price/description) stays uncluttered.

// Comma-separated string ⇄ array helpers for tags/variants text inputs.
const toCsv   = (arr) => (arr || []).map(v => (typeof v === 'string' ? v : v?.name || '')).filter(Boolean).join(', ');
const fromCsv = (str) => str.split(',').map(s => s.trim()).filter(Boolean);

function AdvancedFields({ form, setForm }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10, paddingTop: 4 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        <Input label="Category" value={form.category} placeholder="e.g. services, drinks"
          onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
          hint="'services' marks a bookable item for salon-style flows" />
        <Input label="Stock count" type="number" value={form.stockCount} placeholder="Blank = unlimited"
          onChange={e => setForm(f => ({ ...f, stockCount: e.target.value }))} />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
        <Input label="Currency override" value={form.currency} placeholder="e.g. GMD"
          onChange={e => setForm(f => ({ ...f, currency: e.target.value }))} />
        <Input label="Duration (min)" type="number" value={form.duration} placeholder="e.g. 45"
          onChange={e => setForm(f => ({ ...f, duration: e.target.value }))} />
        <Input label="Prep note" value={form.prep} placeholder="e.g. Arrive early"
          onChange={e => setForm(f => ({ ...f, prep: e.target.value }))} />
      </div>
      <Input label="Tags (comma-separated)" value={form.tagsCsv} placeholder="popular, new, special"
        onChange={e => setForm(f => ({ ...f, tagsCsv: e.target.value }))} />
      <Input label="Variants (comma-separated)" value={form.variantsCsv} placeholder="S, M, L"
        onChange={e => setForm(f => ({ ...f, variantsCsv: e.target.value }))}
        hint="Sizes or options a customer picks before adding to cart" />
      <Toggle
        checked={form.showImageOnSelect}
        onChange={v => setForm(f => ({ ...f, showImageOnSelect: v }))}
        label="Show image when item is selected"
        hint="Turn off to keep responses text-only for this item"
      />
    </div>
  );
}

function ItemRow({ item, onUpdate, onDelete, cloudinaryEnabled, currency }) {
  const [editing, setEditing]   = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [form, setForm] = useState({
    name:        item.name,
    price:       item.price,
    description: item.description || '',
    available:   item.available !== false,
    category:    item.category || '',
    stockCount:  item.stockCount ?? '',
    currency:    item.currency || '',
    duration:    item.duration ?? '',
    prep:        item.prep || '',
    tagsCsv:     toCsv(item.tags),
    variantsCsv: toCsv(item.variants),
    showImageOnSelect: item.showImageOnSelect !== false,
  });
  const [saving, setSaving]     = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [toggling, setToggling] = useState(false);
  const [uploading, setUploading] = useState(false);

  // PATCH /menu/:itemId — edit by _id (not name)
  const save = async () => {
    if (!form.name?.trim()) return;
    setSaving(true);
    try {
      const r = await menuApi.update(item._id, {
        name:        form.name.trim(),
        price:       Number(form.price) || 0,  // ⚠ must be number
        description: form.description || '',
        available:   form.available,
        category:    form.category.trim() || null,
        stockCount:  form.stockCount === '' ? null : Number(form.stockCount),
        currency:    form.currency.trim() || null,
        duration:    form.duration === '' ? null : Number(form.duration),
        prep:        form.prep.trim() || null,
        tags:        fromCsv(form.tagsCsv),
        variants:    fromCsv(form.variantsCsv),
        showImageOnSelect: form.showImageOnSelect,
      });
      const newList = r.data?.menuItems || null;
      const updated = newList?.find(i => i._id === item._id) || { ...item, ...form, price: Number(form.price) || 0 };
      onUpdate(newList, updated);
      setEditing(false);
      toast.success('Item updated');
    } catch (err) { toast.error(err.message); }
    finally { setSaving(false); }
  };

  // DELETE /menu/:itemId — by _id
  const del = async () => {
    setDeleting(true);
    try {
      await menuApi.remove(item._id);
      onDelete(item._id);
      toast.success('Item deleted');
    } catch (err) { toast.error(err.message); }
    finally { setDeleting(false); }
  };

  // PATCH /menu/:itemId — toggle available
  const toggleAvail = async () => {
    setToggling(true);
    try {
      const r = await menuApi.update(item._id, { available: !item.available });
      const newList = r.data?.menuItems || null;
      const updated = newList?.find(i => i._id === item._id) || { ...item, available: !item.available };
      onUpdate(newList, updated);
    } catch (err) { toast.error(err.message); }
    finally { setToggling(false); }
  };

  // POST /menu/:itemId/image — multipart image upload
  const uploadImage = async (file) => {
    if (!file) return;
    if (!cloudinaryEnabled) {
      toast.error('Image uploads aren\'t enabled for this platform yet. Ask your administrator to configure image storage.');
      return;
    }
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('image', file);
      // POST /menu/:itemId/image returns { ok, image, menuItem } — no menuItems array.
      const r = await menuApi.uploadImage(item._id, fd);
      const updated = r.data?.menuItem || { ...item, image: r.data?.image };
      onUpdate(null, updated);
      toast.success('Image uploaded');
    } catch (err) {
      // 503 = Cloudinary not configured on this environment — a graceful, human message
      const msg = err.message?.toLowerCase().includes('cloudinary') || err.message?.includes('503')
        ? 'Image uploads aren\'t set up for this business yet.'
        : err.message;
      toast.error(msg);
    } finally { setUploading(false); }
  };

  const removeImage = async () => {
    setUploading(true);
    try {
      await menuApi.removeImage(item._id);
      onUpdate(null, { ...item, image: null });
      toast.success('Image removed');
    } catch (err) { toast.error(err.message); }
    finally { setUploading(false); }
  };

  return (
    <div style={{ background: 'var(--bg-surface)', border: '1.5px solid var(--border)', borderRadius: 'var(--r-lg)', padding: '14px 18px', marginBottom: 8 }}>
      {editing ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 10 }}>
            <Input label="Name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            <Input label={`Price (${currency || 'D'})`} type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} />
          </div>
          <Input label="Description (optional)" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
          <button
            type="button"
            onClick={() => setShowAdvanced(v => !v)}
            style={{
              display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none',
              color: 'var(--primary)', fontSize: '0.8rem', fontWeight: 600, cursor: 'pointer', padding: '2px 0',
            }}
          >
            {showAdvanced ? <ChevronUp size={14} /> : <ChevronDown size={14} />} Advanced options
          </button>
          {showAdvanced && <AdvancedFields form={form} setForm={setForm} />}
          <div style={{ display: 'flex', gap: 8 }}>
            <Btn size="sm" onClick={save} loading={saving}><Check size={13} /> Save</Btn>
            <Btn size="sm" variant="ghost" onClick={() => setEditing(false)}><X size={13} /> Cancel</Btn>
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          {/* Image thumbnail / upload control */}
          <div style={{ flexShrink: 0, position: 'relative' }}>
            <label
              title={cloudinaryEnabled ? (item.image?.url ? 'Change image' : 'Add image') : 'Image uploads not enabled'}
              style={{
                width: 52, height: 52, borderRadius: 'var(--r-md)', overflow: 'hidden',
                border: '1.5px solid var(--border)', display: 'flex', alignItems: 'center',
                justifyContent: 'center', background: 'var(--bg-overlay)',
                cursor: cloudinaryEnabled ? 'pointer' : 'not-allowed', flexShrink: 0,
              }}
            >
              {uploading ? (
                <Spinner size={16} />
              ) : item.image?.url ? (
                <img src={item.image.url} alt={item.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                cloudinaryEnabled ? <Upload size={16} color="var(--text-ghost)" /> : <ImageIcon size={16} color="var(--text-ghost)" />
              )}
              <input
                type="file" accept="image/*" style={{ display: 'none' }}
                disabled={!cloudinaryEnabled || uploading}
                onChange={e => uploadImage(e.target.files?.[0])}
              />
            </label>
            {item.image?.url && cloudinaryEnabled && (
              <button onClick={removeImage} disabled={uploading} title="Remove image"
                style={{
                  position: 'absolute', top: -6, right: -6, width: 18, height: 18, borderRadius: '50%',
                  background: 'var(--red)', color: '#fff', border: '2px solid var(--bg-surface)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', padding: 0,
                }}>
                <X size={10} />
              </button>
            )}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
              <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>{item.name}</span>
              {!item.available && (
                <span style={{ fontSize: '0.7rem', color: 'var(--text-ghost)', fontWeight: 600 }}>UNAVAILABLE</span>
              )}
              {item.tags?.length > 0 && item.tags.map(tag => (
                <span key={tag} style={{ fontSize: '0.67rem', background: 'var(--primary-dim)', color: 'var(--primary)', borderRadius: 99, padding: '1px 7px', fontWeight: 700 }}>{tag}</span>
              ))}
              {item.category && (
                <span style={{ fontSize: '0.67rem', background: 'var(--bg-overlay)', color: 'var(--text-muted)', borderRadius: 99, padding: '1px 7px', fontWeight: 700, border: '1px solid var(--border)' }}>{item.category}</span>
              )}
              {item.stockCount != null && (
                <span style={{ fontSize: '0.67rem', background: item.stockCount > 0 ? 'var(--blue-dim, var(--bg-overlay))' : 'var(--red-dim)', color: item.stockCount > 0 ? 'var(--blue)' : 'var(--red)', borderRadius: 99, padding: '1px 7px', fontWeight: 700 }}>
                  {item.stockCount} in stock
                </span>
              )}
              {item.variants?.length > 0 && (
                <span style={{ fontSize: '0.67rem', background: 'var(--bg-overlay)', color: 'var(--text-muted)', borderRadius: 99, padding: '1px 7px', fontWeight: 700, border: '1px solid var(--border)' }}>
                  {item.variants.length} option{item.variants.length !== 1 ? 's' : ''}
                </span>
              )}
            </div>
            {item.description && (
              <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: 2 }}>{item.description}</div>
            )}
            <div style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--primary)' }}>
              {formatMoney(item.price, currency, 2)}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 6, flexShrink: 0, alignItems: 'center' }}>
            <button onClick={toggleAvail} disabled={toggling}
              title={item.available ? 'Mark unavailable' : 'Mark available'}
              style={{ color: item.available ? 'var(--primary)' : 'var(--text-ghost)', display: 'flex', cursor: 'pointer', background: 'none', border: 'none', padding: 4 }}>
              {item.available ? <ToggleRight size={20} /> : <ToggleLeft size={20} />}
            </button>
            <Btn variant="ghost" size="sm" onClick={() => setEditing(true)} title="Edit"><Pencil size={13} /></Btn>
            <Btn variant="ghost" size="sm" onClick={del} loading={deleting} style={{ color: 'var(--red)' }} title="Delete">
              <Trash2 size={13} />
            </Btn>
          </div>
        </div>
      )}
    </div>
  );
}

export default function MenuPage() {
  const { user } = useAuth();
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [adding, setAdding]       = useState(false);
  const [form, setForm] = useState({
    name: '', price: '', description: '',
    category: '', stockCount: '', currency: '', duration: '', prep: '',
    tagsCsv: '', variantsCsv: '', showImageOnSelect: true,
  });
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [saving, setSaving]       = useState(false);
  // [FIX-MENU-IMAGES-2] Optional image attached at creation time — backend's
  // POST /:tenantId/menu already accepts multipart with an "image" field
  // (see addMenuItem in dashboardController.js), the create form just never
  // offered a way to use it. newImageFile is the raw File; newImagePreview
  // is a local blob URL for the thumbnail (revoked on reset/unmount).
  const [newImageFile, setNewImageFile]       = useState(null);
  const [newImagePreview, setNewImagePreview] = useState(null);
  // [FIX-MENU-IMAGES] Check whether image storage is configured on this
  // environment before offering an upload control — avoids a confusing
  // "upload failed" the first time someone tries, per Appendix C spec.
  const [cloudinaryEnabled, setCloudinaryEnabled] = useState(false);

  useEffect(() => {
    menuApi.list()
      .then(r => setMenuItems(r.data?.menuItems || []))
      .catch(err => toast.error(err.message))
      .finally(() => setLoading(false));
    bizApi.cloudinaryStatus()
      .then(r => setCloudinaryEnabled(!!r.data?.cloudinaryEnabled))
      .catch(() => setCloudinaryEnabled(false));
  }, []);

  const handleUpdate = (newList, updatedItem) => {
    if (newList) {
      setMenuItems(newList);
    } else {
      setMenuItems(prev => prev.map(i => i._id === updatedItem._id ? updatedItem : i));
    }
  };

  const handleDelete = (deletedId) => {
    setMenuItems(prev => prev.filter(i => i._id !== deletedId));
  };

  // Revoke the object URL behind the create-form image preview and clear it.
  const clearNewImage = () => {
    if (newImagePreview) URL.revokeObjectURL(newImagePreview);
    setNewImageFile(null);
    setNewImagePreview(null);
  };

  const pickNewImage = (file) => {
    if (!file) return;
    if (newImagePreview) URL.revokeObjectURL(newImagePreview);
    setNewImageFile(file);
    setNewImagePreview(URL.createObjectURL(file));
  };

  const add = async () => {
    if (!form.name?.trim()) { toast.error('Name is required'); return; }
    setSaving(true);
    try {
      // [FIX-MENU-IMAGES-2] When an image was attached, POST multipart so the
      // backend's uploadSingle middleware + Cloudinary step in addMenuItem
      // runs; otherwise keep the original plain-JSON request unchanged.
      const advanced = {
        category:    form.category.trim() || null,
        stockCount:  form.stockCount === '' ? null : Number(form.stockCount),
        currency:    form.currency.trim() || null,
        duration:    form.duration === '' ? null : Number(form.duration),
        prep:        form.prep.trim() || null,
        tags:        fromCsv(form.tagsCsv),
        variants:    fromCsv(form.variantsCsv),
        showImageOnSelect: form.showImageOnSelect,
      };
      let payload;
      if (newImageFile) {
        payload = new FormData();
        payload.append('name', form.name.trim());
        payload.append('price', String(Number(form.price) || 0));
        payload.append('description', form.description || '');
        payload.append('image', newImageFile);
        for (const [k, v] of Object.entries(advanced)) {
          if (v === null || v === undefined) continue;
          payload.append(k, Array.isArray(v) ? JSON.stringify(v) : String(v));
        }
      } else {
        payload = {
          name:        form.name.trim(),
          price:       Number(form.price) || 0,  // ⚠ must be number
          description: form.description || '',
          ...advanced,
        };
      }
      const r = await menuApi.add(payload);
      setMenuItems(r.data?.menuItems || menuItems);
      setForm({ name: '', price: '', description: '', category: '', stockCount: '', currency: '', duration: '', prep: '', tagsCsv: '', variantsCsv: '', showImageOnSelect: true });
      setShowAdvanced(false);
      clearNewImage();
      setAdding(false);
      toast.success('Item added');
    } catch (err) { toast.error(err.message); }
    finally { setSaving(false); }
  };

  return (
    <div className="fade-in">
      <PageHeader icon={UtensilsCrossed} title="Menu" subtitle={`${menuItems.length} item${menuItems.length !== 1 ? 's' : ''}`}
        actions={<Btn size="sm" onClick={() => setAdding(v => !v)}><Plus size={14} /> Add Item</Btn>}
      />

      {adding && (
        <Card style={{ marginBottom: 16, borderColor: 'var(--border-accent)' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: '0.9rem', marginBottom: 14 }}>New Menu Item</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 12 }}>
              <Input label="Item name *" value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Jollof Rice" />
              <Input label={`Price (${user?.currency || 'D'})`} type="number" value={form.price}
                onChange={e => setForm(f => ({ ...f, price: e.target.value }))} placeholder="150" />
            </div>
            <Input label="Description (optional)" value={form.description}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Savoury rice cooked in tomato sauce" />

            <button
              type="button"
              onClick={() => setShowAdvanced(v => !v)}
              style={{
                display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none',
                color: 'var(--primary)', fontSize: '0.8rem', fontWeight: 600, cursor: 'pointer', padding: '2px 0',
              }}
            >
              {showAdvanced ? <ChevronUp size={14} /> : <ChevronDown size={14} />} Advanced options
            </button>
            {showAdvanced && <AdvancedFields form={form} setForm={setForm} />}

            {/* [FIX-MENU-IMAGES-2] Optional image at creation time, mirrors the
                per-row control below and stays disabled with the same message
                when Cloudinary isn't configured on this environment. */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <label
                title={cloudinaryEnabled ? 'Add a photo (optional)' : 'Image uploads not enabled'}
                style={{
                  width: 52, height: 52, borderRadius: 'var(--r-md)', overflow: 'hidden',
                  border: '1.5px solid var(--border)', display: 'flex', alignItems: 'center',
                  justifyContent: 'center', background: 'var(--bg-overlay)',
                  cursor: cloudinaryEnabled ? 'pointer' : 'not-allowed', flexShrink: 0, position: 'relative',
                }}
              >
                {newImagePreview ? (
                  <img src={newImagePreview} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : (
                  cloudinaryEnabled ? <Upload size={16} color="var(--text-ghost)" /> : <ImageIcon size={16} color="var(--text-ghost)" />
                )}
                <input
                  type="file" accept="image/*" style={{ display: 'none' }}
                  disabled={!cloudinaryEnabled}
                  onChange={e => pickNewImage(e.target.files?.[0])}
                />
              </label>
              <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                {cloudinaryEnabled
                  ? (newImageFile ? <>{newImageFile.name} <button type="button" onClick={clearNewImage} style={{ background: 'none', border: 'none', color: 'var(--red)', cursor: 'pointer', padding: 0, marginLeft: 6, font: 'inherit' }}>Remove</button></> : 'Photo (optional)')
                  : "Photo uploads aren't turned on for this business yet"}
              </div>
            </div>

            <div style={{ display: 'flex', gap: 8 }}>
              <Btn onClick={add} loading={saving}><Check size={14} /> Add Item</Btn>
              <Btn variant="ghost" onClick={() => { clearNewImage(); setAdding(false); }}>Cancel</Btn>
            </div>
          </div>
        </Card>
      )}

      {!loading && !cloudinaryEnabled && menuItems.length > 0 && (
        <div style={{
          background: 'var(--amber-dim)', border: '1.5px solid rgba(217,119,6,0.22)',
          borderRadius: 'var(--r-md)', padding: '9px 14px', marginBottom: 12,
          fontSize: '0.8rem', color: 'var(--amber)',
        }}>
          Photo uploads aren't turned on for this business yet — items will show as text-only to customers. Contact your administrator to enable this.
        </div>
      )}

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}><Spinner size={28} /></div>
      ) : menuItems.length === 0 ? (
        <Card>
          <EmptyState icon={UtensilsCrossed} title="No menu items yet"
            description="Add items so customers can browse and order via WhatsApp."
            action={<Btn onClick={() => setAdding(true)}><Plus size={14} /> Add first item</Btn>}
          />
        </Card>
      ) : (
        <div>
          {menuItems.map((item) => (
            <ItemRow key={item._id} item={item} onUpdate={handleUpdate} onDelete={handleDelete} cloudinaryEnabled={cloudinaryEnabled} currency={user?.currency} />
          ))}
        </div>
      )}
    </div>
  );
}
