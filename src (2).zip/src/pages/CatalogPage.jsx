import { useEffect, useState } from 'react';
import {
  ShoppingBag, RefreshCw, CheckCircle2, AlertCircle, Clock, XCircle,
  ImageOff, PackageX, Loader2, Info,
} from 'lucide-react';
import { bizApi, catalogApi } from '../api.js';
import { PageHeader, Card, Btn, Input, Select, Toggle, Badge, InfoBanner, StatCard, SectionHeading } from '../components/ui.jsx';
import toast from 'react-hot-toast';

// ── AUDIT NOTE ─────────────────────────────────────────────────────────────
// Backend has a full WA Commerce Catalog subsystem (business/:tenantId/wacatalog
// /health + /sync) with zero frontend surface before this page: a tenant had no
// way to see whether their Meta catalog was connected, healthy, or stale, and
// no way to enable it, configure it, or trigger a sync. This page is that
// surface. All copy below mirrors the exact validation errors the backend
// returns (see updateBusinessSettings's waCatalog branch and syncWaCatalog),
// so a tenant hitting a guard sees the real reason, not a generic failure.

const STATUS_META = {
  not_connected: { label: 'Not Connected', color: 'gray',  Icon: XCircle,     desc: 'Enable the catalog and add your Catalog ID below to get started.' },
  never_synced:  { label: 'Never Synced',  color: 'amber', Icon: Clock,       desc: 'Catalog is configured but has never been synced to Meta yet.' },
  sync_pending:  { label: 'Sync Pending',  color: 'blue',  Icon: Loader2,     desc: 'A recent menu change is queued and will sync automatically shortly.' },
  sync_failed:   { label: 'Sync Failed',   color: 'red',   Icon: AlertCircle, desc: 'The last sync attempt failed — see the error below.' },
  needs_sync:    { label: 'Needs Sync',    color: 'amber', Icon: AlertCircle, desc: "It's been over 24 hours since the last successful sync." },
  healthy:       { label: 'Healthy',       color: 'green', Icon: CheckCircle2, desc: 'Your catalog is up to date with Meta.' },
};

const MODE_OPTIONS = [
  { value: 'AI_DECIDES',   label: 'AI Decides (recommended)', hint: 'The bot offers the catalog only when a customer seems to be browsing.' },
  { value: 'ALWAYS_OFFER', label: 'Always Offer',             hint: 'The bot offers the catalog on every order start.' },
  { value: 'MANUAL_ONLY',  label: 'Manual Only',               hint: 'The catalog is never sent automatically.' },
];

function fmtDate(d) {
  if (!d) return 'Never';
  const date = new Date(d);
  return date.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export default function CatalogPage() {
  const [loading, setLoading]   = useState(true);
  const [health, setHealth]     = useState(null);
  const [phoneOk, setPhoneOk]   = useState(false); // real (non-SIM_) connected number on file
  const [form, setForm]         = useState({ enabled: false, catalogId: '', mode: 'AI_DECIDES' });
  const [saving, setSaving]     = useState(false);
  const [syncing, setSyncing]   = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [h, biz] = await Promise.all([catalogApi.health(), bizApi.getSettings()]);
      setHealth(h.data);
      const wa = biz.data?.business?.waCatalog || {};
      setForm({
        enabled:   !!wa.enabled,
        catalogId: wa.catalogId || '',
        mode:      wa.mode || 'AI_DECIDES',
      });
      const phoneNumberId = biz.data?.business?.phoneNumberId;
      setPhoneOk(!!phoneNumberId && !String(phoneNumberId).startsWith('SIM_'));
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => { load(); }, []);

  const save = async () => {
    if (form.enabled && !form.catalogId.trim()) {
      toast.error('Enter a Catalog ID before enabling the catalog.');
      return;
    }
    setSaving(true);
    try {
      await bizApi.updateSettings({
        waCatalog: {
          enabled:   form.enabled,
          catalogId: form.catalogId.trim(),
          mode:      form.mode,
        },
      });
      toast.success('Catalog settings saved');
      await load();
    } catch (err) {
      // Backend guards surface as clear 400 messages — show them verbatim.
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  const runSync = async () => {
    setSyncing(true);
    try {
      const r = await catalogApi.sync();
      toast.success(`Synced ${r.data.synced || 0} item${r.data.synced === 1 ? '' : 's'}${r.data.deleted ? `, removed ${r.data.deleted}` : ''}`);
      await load();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSyncing(false);
    }
  };

  const meta = STATUS_META[health?.status] || STATUS_META.not_connected;

  return (
    <div className="fade-in">
      <PageHeader
        icon={ShoppingBag}
        title="WhatsApp Catalog"
        subtitle="Sell directly from Meta's WhatsApp Commerce Catalog"
        actions={
          <Btn variant="ghost" size="sm" onClick={load} loading={loading && !!health}>
            <RefreshCw size={14} /> Refresh
          </Btn>
        }
      />

      {!phoneOk && (
        <InfoBanner type="warning" style={{ marginBottom: 20 }}>
          Your WhatsApp number isn't connected yet, so the catalog can't go live even if enabled here.
          Contact your account admin to get WhatsApp connected first.
        </InfoBanner>
      )}

      {!loading && health && (
        <InfoBanner type={meta.color === 'green' ? 'success' : meta.color === 'red' ? 'error' : meta.color === 'gray' ? 'info' : 'warning'} style={{ marginBottom: 20 }}>
          <strong>{meta.label}.</strong> {meta.desc}
          {health.lastSyncError?.reason && (
            <span> Last error: <code>{health.lastSyncError.reason}</code> ({fmtDate(health.lastSyncError.at)})</span>
          )}
        </InfoBanner>
      )}

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}>
          <Loader2 size={28} style={{ animation: 'spin 1s linear infinite', color: 'var(--text-muted)' }} />
        </div>
      ) : (
        <>
          {/* Health stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 14, marginBottom: 20 }}>
            <StatCard label="Status" value={meta.label} icon={meta.Icon} color={meta.color} />
            <StatCard label="Products Live" value={String(health.products ?? 0)} icon={ShoppingBag} color="blue" />
            <StatCard label="Last Synced" value={fmtDate(health.lastSyncedAt)} icon={Clock} color="teal" />
            <StatCard
              label="Data Issues"
              value={String((health.missingImages || 0) + (health.outOfStock || 0))}
              sub={`${health.missingImages || 0} missing image · ${health.outOfStock || 0} out of stock`}
              icon={health.missingImages || health.outOfStock ? ImageOff : PackageX}
              color={(health.missingImages || health.outOfStock) ? 'amber' : 'green'}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 20 }}>
            {/* Configuration */}
            <Card>
              <SectionHeading>Catalog Configuration</SectionHeading>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                <Toggle
                  checked={form.enabled}
                  onChange={v => setForm(f => ({ ...f, enabled: v }))}
                  label="Enable WhatsApp Catalog"
                  hint="Lets customers browse & order products directly inside WhatsApp"
                />
                <Input
                  label="Catalog ID"
                  placeholder="e.g. 1234567890123456"
                  value={form.catalogId}
                  onChange={e => setForm(f => ({ ...f, catalogId: e.target.value }))}
                  hint="Found in Meta Commerce Manager — ask your admin if you don't have this yet"
                />
                <Select
                  label="Offer Mode"
                  value={form.mode}
                  onChange={e => setForm(f => ({ ...f, mode: e.target.value }))}
                  hint={MODE_OPTIONS.find(m => m.value === form.mode)?.hint}
                >
                  {MODE_OPTIONS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
                </Select>
                <Btn onClick={save} loading={saving} fullWidth>Save Catalog Settings</Btn>
              </div>
            </Card>

            {/* Sync */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
              <Card>
                <SectionHeading action={<Badge color={meta.color}>{meta.label}</Badge>}>Sync to Meta</SectionHeading>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: 1.6, marginBottom: 16 }}>
                  Pushes your current menu — name, price, image, and availability — to Meta's Commerce Catalog.
                  Items missing a price or image are skipped automatically. Menu edits also auto-sync in the background,
                  so manual syncing is mainly useful right after a big menu update.
                </p>
                <Btn onClick={runSync} loading={syncing} disabled={!health.connected} fullWidth variant={health.connected ? 'primary' : 'secondary'}>
                  <RefreshCw size={14} /> Sync Now
                </Btn>
                {!health.connected && (
                  <div style={{ fontSize: '0.78rem', color: 'var(--text-ghost)', marginTop: 8, textAlign: 'center' }}>
                    Enable the catalog with a Catalog ID above first.
                  </div>
                )}
              </Card>

              <Card style={{ background: 'var(--bg-overlay)', border: '1.5px solid var(--border)' }}>
                <div style={{ display: 'flex', gap: 10 }}>
                  <Info size={16} color="var(--blue)" style={{ flexShrink: 0, marginTop: 2 }} />
                  <div>
                    <div style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: 4 }}>
                      What makes an item syncable?
                    </div>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', lineHeight: 1.6, margin: 0 }}>
                      Every item needs a valid price and an image to appear in your WhatsApp Catalog. Items missing either
                      are skipped during sync — check <strong>Menu / Products</strong> to fix the {health.missingImages || 0} item(s)
                      currently missing an image.
                    </p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
